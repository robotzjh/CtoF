function [errR, errT] = calERR(grtR, grtT, pM, scannum, s)

errR = 0;
errT = 0;
pM0(1:4,1:3) = [grtR{1,1};0 0 0];
pM0(1:4,4) = [grtT{1,1}*s;1];
pMM0= pM(1).M;
for i=1:scannum
    p(i).M(1:4,1:3) = [grtR{1,i};0 0 0];
    p(i).M(1:4,4) = [grtT{1,i}*s;1];
    p(i).M= inv(pM0)* p(i).M;
    pM(i).M= inv(pMM0)* pM(i).M;
    R1= pM(i).M(1:3,1:3);
    R2= p(i).M(1:3,1:3);
    R12= trace(R1'*R2);
    errR = errR + real(acos(0.5*(R12-1)));
    errT = errT + norm(pM(i).M(1:3,4)-p(i).M(1:3,4),2);
end
errR = errR/scannum;
errT = errT/scannum;



