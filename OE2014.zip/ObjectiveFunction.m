function [Phi] = ObjectiveFunction(MSE, Tr, lamga)

if (nargin<3)
    lamga= 2;
end
Phi = MSE./(Tr.^((1+lamga)));


